package com.simplemobiletools.calculator.operation.base

interface Operation {
    fun getResult(): Double
}
